//
//  AppDelegate.h
//  03 CNProgressView
//
//  Created by wang xinkai on 15/8/29.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


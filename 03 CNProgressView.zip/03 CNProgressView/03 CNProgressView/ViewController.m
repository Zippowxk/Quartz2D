//
//  ViewController.m
//  03 CNProgressView
//
//  Created by wang xinkai on 15/8/29.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    [progressView setValue:30 animated:YES];
    
}
-(IBAction)sliderChange:(UISlider*)sender{

    
    progressView.value = sender.value;
    
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
